from django.shortcuts import render, redirect
from .models import Car
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
# Create your views here.

def home(request):
    cars = Car.objects.all()
    return render(request, 'home.html', {'cars':cars})

def about(request):
    return render(request, 'about.html', {})


def detail(request,id_car):
    car=Car.objects.get(id=id_car)

    category=car.category 
    car_in_relation = Car.objects.filter(category=category)
    return render(request,'detail.html',{"car":car,"cir":car_in_relation})



# def login_user(request):

#     if request.method == "POST":
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         user = authenticate(request ,username=username, password=password)

#         if user is not None:
#             login(request, user)
#             messages.success(request,('succesfully logged in '))
#             return redirect('home')
#         else:
#             messages.info(request, ('username or password incorect '))
#             return redirect('login')
#     else:
#         return render(request, 'login.html', {})


# def logout_user(request):
    # logout(request)
    # messages.success(request, ('You have been loged out '))
    # return redirect('home')
