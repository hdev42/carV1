from django.contrib import admin

# here i import all of my models to show them in the database 
from .models import *
# Register your models here.

admin.site.register(Category)
admin.site.register(Car)
admin.site.register(Order)
# admin.site.register(Customer)
admin.site.register(Type)
admin.site.register(Brand)





