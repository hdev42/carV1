from django import forms
from .models import Car

class CarForm(forms.ModelForm):
    
    class Meta:
        model = Car
        fields = ["name", 'brand', 'price', 'type','category', 'description', 'image', 'image_desc1','image_desc2','image_desc3', 'places', 'year', 'new']
        label = {'name':'name', 'category':'category', 'description':'Description', 'type':'type', 'brand':'brand', 'price':'price', 'year':'year','new':'new', 'places':'places'}
        widget = {
            'name': forms.TextInput(attrs={'class':'form-control'}),
            'category': forms.Select(attrs={'class':'form-control'}),
            'type': forms.Select(attrs={'class':'form-control'}),
            'brand': forms.Select(attrs={'class':'form-control'}),
            'price': forms.DecimalField(),
            'places': forms.DecimalField(),

            'description': forms.Textarea  (attrs={'class':'form-control', 'row':5}),
            'year': forms.Textarea  (attrs={'class':'form-control', 'row':5}),
            'new': forms.BooleanField()

        }
        