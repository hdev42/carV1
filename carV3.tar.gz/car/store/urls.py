from django.urls import path, include
from . import views
from app_auth.views import *

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    # path('login/', views.login_user, name='login'),
    # path('logout/', views.logout_user, name='logout'),
    path('car/<int:id_car>',views.detail,name="detail"),
    # path('article/recherche',search,name="search"),
    path('my-admin/', include("app_admin.urls")),


]
