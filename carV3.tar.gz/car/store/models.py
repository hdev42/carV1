from django.db import models
import datetime
from django.contrib.auth.models import User


# Create your models here.



# Category de voiture 
class Category(models.Model):
    name = models.CharField( max_length=50)

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'categories'

# class Customer(models.Model):
#     first_name = models.CharField( max_length=50)
#     last_name = models.CharField( max_length=50)
#     phone = models.CharField( max_length=15)
#     email = models.EmailField( max_length=100)
#     password = models.CharField( max_length=50)

#     def __str__(self):
#         return f'{self.first_name} {self.last_name}'


class seller(models.Model):
    pass



class Type(models.Model):
    name = models.CharField(max_length=50, default='test')

    def __str__(self):
        return self.name



class Brand(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name




# voila l'objet de la voiture avec tous les champ qui serons utiliser dans la base de donne 
# here is the Car object wih all the fields which will be saved in the data base 
class Car(models.Model):
    name = models.CharField( max_length=100)
    price = models.DecimalField(default=0,max_digits=8, decimal_places=2)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    description = models.CharField(max_length=300, default='', blank=True, null=True)
    image = models.ImageField(upload_to='uploads/car')
    year = models.CharField(max_length=4)
    places = models.CharField(max_length=20)
    new = models.BooleanField(default=True)
    type = models.ForeignKey(Type, on_delete=models.CASCADE, default=1)
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, default=1)
    image_desc1 = models.ImageField(upload_to='uploads/car', blank=True, null=True)
    image_desc2 = models.ImageField(upload_to='uploads/car', blank=True, null=True)
    image_desc3 = models.ImageField(upload_to='uploads/car',blank=True, null=True)

    

    def __str__(self):
        return self.name


# Customer Orders 
# 
class Order(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    adress = models.CharField(max_length=100, default = True, blank=True)
    phone = models.CharField(max_length=20, default='', blank=True)
    date = models.DateField(default=datetime.datetime.today)
    status = models.BooleanField(default=False)

    def __str__(self):
        return {self.car}
    