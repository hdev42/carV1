from django.shortcuts import render,redirect
from django.views.generic.edit import UpdateView,CreateView,DeleteView
from  store.models import Car
from store.forms import CarForm

def dashboard(request):
    return render(request, 'db.html')

def user_car(request):
    if not request.user.is_authenticated:
        return redirect('home')
    list_car = Car.objects.filter(user=request.user)
    return render(request,'my-articles.html',{'list_car':list_car})

class AddCar(CreateView):
    model = Car
    form_class = CarForm
    template_name = "add-article.html"
    success_url = "my-car"
    
    def form_valid(self,form):
        form.instance.user=self.request.user
        return super().form_valid(form)
    
class UpdateCar(UpdateView):
        model = Car
        form_class = CarForm
        template_name = 'app_admin/article_form.html'
        success_url = "/my-admin/my-car"
        
        
    
class DeleteCar(DeleteView):
    model = Car
    success_url = "/my-admin/my-car"
    

        