from django.urls import path
from .views import *

urlpatterns = [
    path('', dashboard, name="dashboard"),
    path('my-car', user_car, name="my-car"),
    path('add-car', AddCar.as_view(), name="add-car"),
    path('update-car<int:pk>',UpdateCar.as_view(), name="update-car"),
    path('delete-car<int:pk>',DeleteCar.as_view(), name="delete-car"),
]
                                                                                                                                                                                                                                                         