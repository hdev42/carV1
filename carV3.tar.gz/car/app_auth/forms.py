from django import forms

class LoginForm(forms.Form):
    username = forms.CharField( label="Username" , widget=forms.TextInput(attrs={'class':'form-control'}))
    pwd = forms.CharField(label="Password" ,widget=forms.PasswordInput(attrs={'class':'form-control'}))

class RegisterForm(forms.Form):
    username = forms.CharField( label="Username" , widget=forms.TextInput(attrs={'class':'form-control'}))
    # emai = forms.CharField(label="email", widget=forms.EmailInput(attrs={'class':'form-control'}))
    pwd = forms.CharField(label="Password" ,widget=forms.PasswordInput(attrs={'class':'form-control'}))
    pwd_confirm = forms.CharField(label="confirm your Password", widget=forms.PasswordInput(attrs={'class': 'form-control'}))

