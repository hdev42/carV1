from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .forms import *


def login_blog(request):
    if request.method == "POST":
        form = LoginForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            pwd = form.cleaned_data['pwd']
            user = authenticate(username=username, password=pwd)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, "Authentification Failed")
                return render(request, "login.html", {'form': form})
        else:
            return render(request, "login.html", {'form': form})
    else:
        form = LoginForm()
        return render(request, "login.html", {"form": form})


def register(request): 
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email =request.POST['email']
        country = request.POST['country']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Email is exist ')
                return redirect(register)
            else:
                user = User.objects.create_user(username=username,
                password=password, email=email, first_name=first_name, last_name=last_name, country=country)
                user.set_password(password)
                User.is_superuser=True
                user.save()

                return redirect('login-blog')
        else:
            messages.info(request, 'Both passwords are not matching')
            return redirect(register)
    
    else :
        return render(request,"register.html")
    
def logout_user(request):
    auth.logout(request)
    return redirect('home') 

# def register(request):
#     if request.method == "POST":
#         form = RegisterForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             pwd = form.cleaned_data['pwd']
#             user = User.objects.create_user(username=username, password=pwd)
#             if user is not None:
#                 return redirect("login-blog")
#             else:
#                 messages.error(request, 'Account Creation Failure')
#                 return render(request, 'register.html', {'form': form})
#         else:
#             return render(request, 'register.html', {'form': form})
#         return render(request, 'register.html', {})

#     form = RegisterForm()
#     return render(request, 'register.html', {'form': form})

